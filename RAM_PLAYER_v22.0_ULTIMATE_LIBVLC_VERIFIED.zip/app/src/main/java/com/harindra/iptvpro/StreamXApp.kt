package com.harindra.iptvpro

import android.app.Application
import android.content.ComponentCallbacks2
import android.util.Log
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory

/**
 * Global ComponentCallbacks2 Memory Guard for 512MB RAM Android TVs (v17.0 Ultra Extreme Edition).
 * Keeps total memory footprint well within hardware limits by trimming non-visible Glide bitmaps,
 * releasing idle in-memory channel/EPG caches, and evicting idle preload segments on low-memory
 * signals while keeping active live TV playback uninterrupted.
 */
class StreamXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            Glide.get(this).setMemoryCategory(MemoryCategory.LOW)
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
            ) {
                Log.i("StreamX", "Global Memory Guard triggered (level=$level): clearing non-visible caches")
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                EpgCacheStore.trimMemoryCache()
                XmltvParser.trimProgrammeDetailsCache()
                NetworkClient.evictIdleConnections()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            EpgCacheStore.trimMemoryCache()
            XmltvParser.trimProgrammeDetailsCache()
            NetworkClient.evictIdleConnections()
        }
    }
}
