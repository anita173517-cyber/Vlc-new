# RAM PLAYER v19.0 — Source Audit & Patch Report

Audit basis: the uploaded `RAM_PLAYER_v19.0_Extreme_Master_Edition.zip` (120 archive entries; 16 Kotlin source files; 1 existing Kotlin unit-test file; 64 XML resources; one Activity layout). This report distinguishes source-level evidence from runtime verification.

## Executive result

The archive is a substantial v19.0 Android TV project, not an empty shell. It contains Media3 playback, M3U/Xtream ingestion, XMLTV parsing/cache, profile-scoped stores, playlist WorkManager code, audio/subtitle delay code, prefetching, VOD/series catalogs, TV-oriented dialogs/navigation, diagnostics, and backup/restore code.

However, the master order is **not fully implemented**. Several changelog/README claims are broader than what the code and tests establish. The project is heavily concentrated in a 10,269-line `PlayerActivity.kt`; it has no Room/SQLite database, no ViewModels, no Fragments, and no dedicated playback Service. The supplied verifier is structural/resource-oriented, not a Kotlin compiler or full behavioral test suite.

## Patch applied in this delivery

1. Added stack-aware glass-dialog dismissal tracking in `PlayerActivity.present4dGlassDialog()`.
2. When the final overlay closes, the app waits briefly for any replacement dialog to open, then checks that the app is alive, the playback mode is Live TV, the VOD panel is not visible, and a suspended Live TV session still exists. It then calls the existing restore path. This is intended to fix Settings/Search/overlay return without restarting between nested settings dialogs.
3. Changed the default for `autoReconnectLiveTvOnReturn` from false to true. Users who explicitly saved false still retain that preference.
4. Added `LiveTvBackgroundPlaybackControllerTest.kt` covering suspend conditions and save/consume restoration state.

**Important:** this patch is source-level and has not been compiled or exercised on a TV in this environment. It is not honestly labelable as implemented-and-tested yet.

## Requirement audit

Status vocabulary:
- **IMPLEMENTED (SOURCE EVIDENCE)** — meaningful implementation exists; runtime/device behavior not proven here.
- **PARTIAL** — some parts exist, but required integration, coverage, or safeguards are missing.
- **NOT IMPLEMENTED / NOT FOUND** — no corresponding implementation was found in the archive.
- **NOT VERIFIED** — code may exist, but there is insufficient evidence or no runnable test.

| Area / requirement | Status | Evidence and remaining work |
|---|---|---|
| Kotlin/Java project audit | IMPLEMENTED (SOURCE EVIDENCE) | 16 Kotlin files inspected; no Java files. |
| Activities / navigation | PARTIAL | One very large `PlayerActivity`; no Fragments/ViewModels; navigation is imperative and dialog-driven. |
| Playback service / background session | NOT IMPLEMENTED / NOT FOUND | No MediaSessionService/Foreground Service. Activity owns ExoPlayer. |
| Database / migrations / indexes | NOT IMPLEMENTED / NOT FOUND | No Room/SQLite schema or migration framework; state is SharedPreferences and JSON/cache files. |
| Android TV launcher / leanback | IMPLEMENTED (SOURCE EVIDENCE) | LEANBACK_LAUNCHER, banner, non-touchscreen feature declarations and remote focus code exist. |
| D-pad / remote navigation | PARTIAL | Focusable controls and key mappings exist; no physical remote matrix test or automated navigation tests. |
| 720p/1080p/4K / overscan | PARTIAL | Responsive sizing and overscan preference exist; no multi-resolution visual test evidence. |
| Audio delay | PARTIAL | Media3 PCM `AudioProcessor` is wired into `DefaultAudioSink`; bypasses encoded bitstream/passthrough. Device-level sync and stream-change tests absent. |
| Subtitle delay | PARTIAL | Cue delay and generation cancellation exist; delayed cue behavior across formats, seek/pause/resume and channel changes has no tests. |
| Playlist periodic refresh | PARTIAL | WorkManager periodic worker, network/battery constraints, retry and unique work exist. Work name is global while worker refreshes only active profile; not one schedule per playlist/profile. |
| Refresh on startup / manual / status | PARTIAL | Startup/manual/status paths exist in Activity/Store; no end-to-end worker tests. |
| Daily/custom schedule | PARTIAL | Interval-based periodic scheduling (hours) exists; no calendar-time daily/custom schedule editor found. |
| Audio passthrough vs offload | PARTIAL | Separate preference/code paths and capability checks exist; actual output route/format negotiation needs device verification. |
| Versioned backup / encryption | PARTIAL | SXBK_V19/V20 validation and AES-GCM password helper exist. |
| Backup full coverage | PARTIAL | Includes many profile/settings fields, but export/restore is not a complete snapshot of every per-profile field. Continue-watching progress, all profile-scoped preferences and all playlist state are not proven covered. |
| Restore safety / rollback | PARTIAL | Validation and additive restore exist; no transactional rollback. A failure after partial writes can leave partial restore. |
| Credential safety | PARTIAL | Encrypted profile preferences and redaction helpers exist; optional backup credentials require careful encrypted export workflow and security review. |
| Profile isolation | PARTIAL | Many IDs/preferences are scoped by account ID; some app-level preferences and settings remain global. No cross-profile integration test. |
| Premium home dashboard | PARTIAL | Cinematic Home Hub and configurable rows/sidebar exist; not a full independently rendered dashboard with all requested content rails. |
| Live TV channel features | PARTIAL | Groups, favorites, search, hide/blacklist, custom names, duplicate detection, EPG data and channel management exist. Channel preview/health coverage is not the full requested diagnostics suite. |
| Fast zapping / prefetch | PARTIAL | `StreamPreFetcher` includes bounded caches, cancellation and preload logic; actual first-frame/zap measurements absent. |
| Live channel broken-stream diagnosis | PARTIAL | Playback error/retry and prefetch classification exist; no full catalog-wide safe stream health scan or verified diagnostics matrix. |
| Media3 playback / hardware fallback | IMPLEMENTED (SOURCE EVIDENCE) | Media3 ExoPlayer, HLS/DASH/RTSP, decoder fallback configuration and track selection paths exist. |
| Audio/subtitle track selection | IMPLEMENTED (SOURCE EVIDENCE) | Player track-selection UI/code exists. |
| Aspect ratio / speed / seek | IMPLEMENTED (SOURCE EVIDENCE) | Resize, speed and seek controls exist. |
| HDR / resolution / codec information | PARTIAL | Some track and display capability diagnostics exist; actual per-stream HDR/codec reporting depends on device/API. |
| Playback recovery | PARTIAL | Retry/watchdog and error classification exist; bounded retries and real-world recovery need tests. |
| External player / PiP / sleep timer / lock | IMPLEMENTED (SOURCE EVIDENCE) | Corresponding paths and manifest PiP support exist; device verification absent. |
| VOD movies and series | PARTIAL | Xtream catalog, movie details, seasons/episodes, watchlists and progress exist; metadata completeness depends on provider. |
| Auto-next / skip intro | PARTIAL | Auto-next exists; reliable skip-intro marker support not established. |
| XMLTV / EPG parsing and cache | IMPLEMENTED (SOURCE EVIDENCE) | `XmltvParser`, `EpgCacheStore`, channel matching and EPG UI paths exist; no XMLTV unit tests. |
| Multiple playlists / Xtream | PARTIAL | Profile model supports M3U/Xtream; refresh and catalog flows exist. Playlist-specific schedule and robust import/export migration need work. |
| Settings categories | PARTIAL | Source describes a 15-category Settings Center while prompt asks for 24; searchable settings advertises 24. Category coverage and live control wiring require a category-by-category audit. |
| Unified search / voice | IMPLEMENTED (SOURCE EVIDENCE) | Smart search and Android RecognizerIntent path exist; search history persistence and multi-type result correctness need tests. |
| Network monitoring / recovery | PARTIAL | OkHttp/network callbacks, connectivity status and retry paths exist; adaptive buffer and comprehensive DNS diagnostics not proven. |
| Storage manager | PARTIAL | Cache sizes/clear paths exist; no complete storage inventory for all cache/temp/user data. |
| App health dashboard | PARTIAL | Diagnostics UI and device/player/cache summaries exist; several labels are snapshots, not continuously verified health. |
| Accessibility | PARTIAL | Focus indicators, high contrast and text/layout settings exist; TalkBack semantics and reduced-motion coverage need testing. |
| Privacy controls | PARTIAL | Search/history clearing and redaction paths exist; complete data export/delete and credential-management workflow not proven. |
| Screensaver / idle | PARTIAL | Screensaver preference/idle paths exist; artwork and burn-in behavior need TV validation. |
| Startup / first-run setup | PARTIAL | Setup wizard state and boot/startup paths exist; complete guided restore/profile/playlist flow needs validation. |
| 512MB / low-RAM optimization | PARTIAL | Bounded caches, Glide low-memory trimming, decoder extension disable and heap guards exist. No 512MB device test or measured performance results. |
| Security / permissions | PARTIAL | Credential encryption, PIN hashing, URL redaction and input sanitization exist. Manifest enables cleartext traffic globally; tighten to HTTPS by default with explicit per-source opt-in if legacy IPTV HTTP is required. |
| Architecture / maintainability | PARTIAL | Kotlin and repositories/helpers exist, but the 10k-line Activity remains a major lifecycle/testability risk. |
| Unit tests | PARTIAL | Original archive had one M3U parser test file. This patch adds pure controller tests. Tests have not been executed. |
| XML/resource validation | IMPLEMENTED AND TESTED | `scripts/verify_project.py` ran successfully after the patch: XML parsed and referenced resource symbols resolved. |
| Kotlin compile / Gradle unit tests | NOT VERIFIED | Not run: archive has no `gradle-wrapper.jar`; environment has no installed Gradle, Kotlin compiler, or Android SDK. |
| APK build / installation | NOT VERIFIED | No APK built; no Android device/emulator available. |
| TV remote / real stream / 2GB TV | NOT VERIFIED | Requires target hardware and real playlist/test streams. |
| Performance measurements | NOT VERIFIED | No measured startup, zap, first-frame, memory, EPG or recovery benchmark results in this environment. |

## High-priority remaining work

1. Introduce a dedicated `MediaSessionService`/playback owner so player lifetime is independent of Activity/dialog lifecycle; this is the robust long-term fix for navigation and background/foreground transitions.
2. Make playlist refresh unique per profile/playlist, pass the playlist ID in WorkManager input, and refresh that exact playlist rather than whichever profile happens to be active.
3. Replace backup restore with a staged, validated, transactional restore; include every profile and its playback progress/settings, and test rollback.
4. Add Room (or a carefully versioned persistent store) for large catalogs, history and progress; SharedPreferences should not hold high-volume state.
5. Split `PlayerActivity` into testable navigation, playback, settings, playlist and EPG components without changing the current visual identity.
6. Add parser/backup/profile/worker/player state tests and run them in CI; add emulator smoke tests and physical TV remote tests.
7. Verify audio delay/subtitle delay and passthrough on actual codecs/output devices; expose capability-specific status rather than assuming all streams support it.
8. Add actual performance benchmark instrumentation before making 512MB/2GB device performance guarantees.
9. Review global `usesCleartextTraffic=true`; provide a secure migration path for IPTV sources that still require HTTP.
10. Finish the requested 24 Settings categories with a traceable UI → persisted value → runtime effect test for each setting.

## Build / test facts

- Structural verifier: **PASS** after source patch.
- XML parse and resource-reference validation: **PASS** through `scripts/verify_project.py`.
- Kotlin compilation: **NOT RUN**.
- JUnit: **NOT RUN**.
- Debug/release APK: **NOT BUILT**.
- Installation / Android TV: **NOT RUN**.
- Reason: this environment has no Android SDK, no installed Gradle/Kotlin compiler, and the ZIP omits `gradle/wrapper/gradle-wrapper.jar`. The included wrapper script alone cannot bootstrap Gradle without that JAR.
